The .scss (Sass) files are only available in the pro version.
You can buy it from: https://bootstrapmade.com/mamba-one-page-bootstrap-template-free/